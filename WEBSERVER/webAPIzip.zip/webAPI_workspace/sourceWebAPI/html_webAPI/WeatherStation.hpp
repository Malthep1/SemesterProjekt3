#include <restinio/all.hpp>
#include <vector>
#include "StationDataT.hpp"

using std::vector;

struct weatherStation{
    weatherStation() = default;

    weatherStation(weatherRegistration wr){}
};

