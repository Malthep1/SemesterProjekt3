//#include "WeatherStation.hpp"
#include "wDataHandler.hpp"
#include <iostream>

using std::cout;

int main(void){

    cout << "Main online\n";
    
    //wDataHandler handler;
    

    return run();
}


