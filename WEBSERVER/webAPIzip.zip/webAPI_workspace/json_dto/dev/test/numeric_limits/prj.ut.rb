require 'mxx_ru/binary_unittest'

Mxx_ru::setup_target(
	Mxx_ru::Binary_unittest_target.new(
		"test/numeric_limits/prj.ut.rb",
		"test/numeric_limits/prj.rb" )
)
